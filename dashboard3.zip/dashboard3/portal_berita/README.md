
# Portal Berita

Portal berita sederhana dengan fitur:
1. Menampilkan daftar berita.
2. Pencarian berita berdasarkan judul atau konten.
3. Upload berita baru.

## Konfigurasi
1. Buat database `portal_berita` dan tabel `berita` sesuai SQL yang disediakan.
2. Pastikan folder `uploads/` dapat ditulis oleh server.

## Cara Menjalankan
1. Letakkan folder ini di dalam direktori server (misalnya: `htdocs` untuk XAMPP).
2. Akses melalui browser di `http://localhost/portal_berita/`.
