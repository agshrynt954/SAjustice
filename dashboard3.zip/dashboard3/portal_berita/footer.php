<footer class="bg-light text-center text-lg-start mt-4">
    <div class="container p-4">
        <p class="text-center">&copy; <?php echo date("Y"); ?> Portal Berita. Semua Hak Dilindungi.</p>
    </div>
</footer>
<style>
    footer {
        position: relative;
        bottom: 0;
        width: 100%;
        padding-top: 10px;
    }
</style>
